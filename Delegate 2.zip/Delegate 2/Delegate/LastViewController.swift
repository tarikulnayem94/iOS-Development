//
//  LastViewController.swift
//  Delegate
//
//  Created by MACLAB on 17/11/18.
//  Copyright © 2018 jannat. All rights reserved.
//

import UIKit

class LastViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func StudentPic(_ sender: UIButton) {
        
        msg = "Teacher"
        let teacher = Notification.Name(rawValue: TeacherKey)
        NotificationCenter.default.post(name :)
        
        
    }
    @IBAction func TeacherPic(_ sender: UIButton) {
    }
}
