//
//  ViewController.swift
//  DataPassingWithSegue
//
//  Created by lab on 11/17/18.
//  Copyright © 2018 sa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var homeVClabel: UILabel!
    
    @IBOutlet weak var homeVCtext: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func prepare( for segue: UIStoryboardSegue, sender: Any?){
        
        let NextVC = segue.destination as! AnotherViewController
        NextVC.textt = homeVCtext.text!
        
    }
    
    @IBAction func unWinedSegue(_ sender: Any) {
        
        let anotherVC = (sender as AnyObject).source as! AnotherViewController
        
        
        
    }
}

