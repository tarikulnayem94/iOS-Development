//
//  AnotherViewController.swift
//  DataPassingWithSegue
//
//  Created by lab on 11/17/18.
//  Copyright © 2018 sa. All rights reserved.
//

import UIKit

class AnotherViewController: UIViewController {

    
    @IBOutlet weak var anotherVClabel: UILabel!
    
    @IBOutlet weak var anotherVCtext: UITextField!
    
    var textt:String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        anotherVClabel.text = textt
    }
    

}
