
#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touched)];
    [self.view addGestureRecognizer:tap];

}

-(void)touched{
    [self.view endEditing:YES];
}


- (IBAction)loginButtonAction:(id)sender {
    
    if([self.nameTextField.text isEqualToString:@"digi"] && [self.passTextField.text isEqualToString:@"123"]) {
        
        NSLog(@"%@", self.nameTextField.text);
        
        UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        
        HomeViewController *vc = [board instantiateViewControllerWithIdentifier:@"HomeViewControllerID"];
        vc.passString = [NSString stringWithFormat:@"Welcome %@", self.nameTextField.text];
        [self.navigationController pushViewController:vc animated:YES];
    }
    else {
        NSLog(@"Login Failed");
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Login Failed"
                                                                       message:@"Name or Password wrong. Try again!"
                                                                preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * action) {}];
        
        [alert addAction:defaultAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
    
    
}



@end
