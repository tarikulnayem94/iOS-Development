//
//  ViewController.swift
//  Delegate
//
//  Created by lab on 11/12/18.
//  Copyright © 2018 jannat. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
    @IBOutlet weak var HomeLabel: UILabel!
    @IBOutlet weak var HomeButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        HomeButton.layer.cornerRadius = HomeButton.frame.size.height/2
        
        
    }

@IBAction func ButtonPress(_ sender: Any) {
        
        let SelectionVC = storyboard?.instantiateViewController(withIdentifier: "one") as! SelectionViewController
    
        SelectionVC.DelegateObject = self
        present(SelectionVC, animated: true, completion: nil)
    }
    
}

extension ViewController:SelectionDelegate{
    func Delegate(MSG: String, Type: String) {
        HomeLabel.text = Type + "and MSG is - " + MSG
    
    }
}

