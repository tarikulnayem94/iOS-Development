//
//  MenuDetailsViewController.h
//  Restaurant Menu
//
//  Created by Admin on 9/17/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FoodMenu.h"

NS_ASSUME_NONNULL_BEGIN

@interface MenuDetailsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *menuImageView;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UITextView *descLabel;
@property (strong, nonatomic)  FoodMenu *menu;

@end

NS_ASSUME_NONNULL_END
