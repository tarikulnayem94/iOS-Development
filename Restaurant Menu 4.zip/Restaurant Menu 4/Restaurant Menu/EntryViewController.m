//
//  EntryViewController.m
//  Restaurant Menu
//
//  Created by Admin on 9/12/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import "EntryViewController.h"

@interface EntryViewController ()

@end

@implementation EntryViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    menuArray = [[NSMutableArray alloc] init];
    
    self.title = @"Add Menu";
}

- (IBAction)selectPhotoAction:(id)sender {
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    self.pickedImageView.image = chosenImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (IBAction)addButtonAction:(id)sender {

    /*
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    
    [dic setObject:self.nameTextField.text forKey:@"NAME"];
    [dic setObject:self.descTextField.text forKey:@"DESC"];
    [dic setObject:self.imageTextField.text forKey:@"IMAGE"];
    
    [menuArray addObject:dic];
     */
    
    
    FoodMenu *menu = [[FoodMenu alloc] init];
    menu.name = self.nameTextField.text;
    menu.desc = self.descTextField.text;
    menu.imageName = self.imageTextField.text;
    menu.image = self.pickedImageView.image;
    
    [menuArray addObject:menu];


}

- (IBAction)showButtonAction:(id)sender {
    
    NSLog(@"%@", menuArray);
    
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    MenuListViewController *vc = [board instantiateViewControllerWithIdentifier:@"MenuListViewControllerID"];
    vc.menuItems = [NSArray arrayWithArray:menuArray];
    [self.navigationController pushViewController:vc animated:YES];
}



@end
