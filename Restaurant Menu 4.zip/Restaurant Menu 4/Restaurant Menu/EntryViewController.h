//
//  EntryViewController.h
//  Restaurant Menu
//
//  Created by Admin on 9/12/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuListViewController.h"
#import "FoodMenu.h"

NS_ASSUME_NONNULL_BEGIN

@interface EntryViewController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate> {
  
    NSMutableArray *menuArray;

}

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *descTextField;
@property (weak, nonatomic) IBOutlet UITextField *imageTextField;
@property (weak, nonatomic) IBOutlet UIImageView *pickedImageView;

@end

NS_ASSUME_NONNULL_END
