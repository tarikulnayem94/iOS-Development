//
//  MenuListViewController.h
//  Restaurant Menu
//
//  Created by Admin on 9/12/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuTableViewCell.h"
#import "FoodMenu.h"
#import "MenuDetailsViewController.h"
#import "MenuTableViewAutoCell.h"


NS_ASSUME_NONNULL_BEGIN

@interface MenuListViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>


@property (weak, nonatomic) IBOutlet UITableView *menuTableView;
@property (strong, nonatomic)  NSArray *menuItems;

@end

NS_ASSUME_NONNULL_END
