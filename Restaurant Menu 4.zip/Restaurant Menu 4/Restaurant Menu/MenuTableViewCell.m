//
//  MenuTableViewCell.m
//  Restaurant Menu
//
//  Created by Admin on 9/12/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import "MenuTableViewCell.h"

@implementation MenuTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
