//
//  MoviewListViewController.m
//  API Movie
//
//  Created by Admin on 10/4/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import "MoviewListViewController.h"

static NSString *MovieDomain = @"https://api.themoviedb.org";
static NSString *Movie_Token = @"888e98010b8b073de114f1824bb1257b";
static NSString *Movie_Token2 = @"4df263f48a4fe2621749627f5d001bf0";


@interface MoviewListViewController (){
    
    NSArray *dataArray;
    API *apiClass;

}

@end

@implementation MoviewListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.dataListTableView.delegate  = self;
    self.dataListTableView.dataSource = self;
    
    
}

- (IBAction)rattedAction:(id)sender {
    
   
}


- (IBAction)favouriteAction:(id)sender {
   
}

- (IBAction)recentAction:(id)sender {
   
}



- (IBAction)dummayButtonAction:(id)sender {
    
    [self performSelector:@selector(showLoadingView:) onThread:[NSThread mainThread] withObject:@"Getting data, please wait..." waitUntilDone:YES];
    [self performSelector:@selector(dummydata) withObject:nil afterDelay:0.01];
}

-(void)dummydata{
    
    NSString *url = @"https://jsonplaceholder.typicode.com/photos";
    
    apiClass = [[API alloc] initWithUrl:url apiName:@"Dummy" PostData:nil];
    apiClass.delegate = self;
    [apiClass accessAPI:@"GET" Synchronous:YES];
}

-(void)getMovie:(NSString*)url{
    
   
}


-(void)apiDidExecute:(API *)api apiName:(NSString *)apiName data:(id)data{
    
    [self CloseLoadingView];
    
    dataArray = [[NSArray alloc] initWithArray:data];
   
    [ self.dataListTableView reloadData];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 150;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
   
    NSDictionary *dataDic  = [dataArray objectAtIndex:indexPath.row];
    NSString *title  = [dataDic objectForKey:@"title"];
   
    NSString *imageName  = [dataDic objectForKey:@"url"];
    NSURL *url = [NSURL URLWithString:imageName];
    
    ItemTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ItemTableViewCellID"];
    
    cell.itemNameLabel.text = title;
    [cell.itemImageView sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"placeholder.png"]];
    
    return cell;
}

-(void)showLoadingView:(NSString*)text{
    [[LoadingView alloc] initWithText:text Delegate:self];
    [LoadingView Show];
}

-(void)CloseLoadingView{
    [LoadingView Close];
}


@end
