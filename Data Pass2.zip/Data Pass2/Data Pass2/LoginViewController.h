//
//  LoginViewController.h
//  Data Pass2
//
//  Created by Admin on 9/8/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;

@end

NS_ASSUME_NONNULL_END
