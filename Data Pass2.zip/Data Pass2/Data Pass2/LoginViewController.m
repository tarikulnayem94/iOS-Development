
#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touched)];
    [self.view addGestureRecognizer:tap];

}

-(void)touched{
    [self.view endEditing:YES];
}


- (IBAction)loginButtonAction:(id)sender {
    
    NSLog(@"%@", self.nameTextField.text);
    
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    HomeViewController *vc = [board instantiateViewControllerWithIdentifier:@"HomeViewControllerID"];
    vc.passString = self.nameTextField.text;
    [self.navigationController pushViewController:vc animated:YES];
    
}



@end
