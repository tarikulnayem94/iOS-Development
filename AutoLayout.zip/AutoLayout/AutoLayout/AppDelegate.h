//
//  AppDelegate.h
//  AutoLayout
//
//  Created by lab on 9/19/18.
//  Copyright © 2018 Digicon lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

