//
//  HomeViewController.m
//  Data Pass2
//
//  Created by Admin on 9/8/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import "HomeViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"HomeViewController load");
    self.detailsLabel.text = self.passString;
}



@end
