//
//  HomeViewController.h
//  Data Pass2
//
//  Created by Admin on 9/8/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *detailsLabel;
@property (strong, nonatomic)  NSString *passString;

@end

NS_ASSUME_NONNULL_END
