//
//  FirstViewController.swift
//  Local_observer_use
//
//  Created by lab on 11/19/18.
//  Copyright © 2018 sa. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var close: UIButton!
    @IBOutlet weak var a1: UIButton!
    @IBOutlet weak var a2: UIButton!
    @IBOutlet weak var a3: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func firstViewClose(_ sender: Any) {
        let firstVC = storyboard?.instantiateViewController(withIdentifier: "homeStoryboard") as! ViewController
        present(firstVC, animated: true, completion: nil)
    }
    
    @IBAction func press_A1(_ sender: Any) {
        let noti_A1 = Notification.Name(rawValue: key_A1)
        NotificationCenter.default.post(name: noti_A1, object: nil)
    }
    @IBAction func press_A2(_ sender: Any) {
        let noti_A2 = Notification.Name(rawValue: key_A2)
        NotificationCenter.default.post(name: noti_A2, object: nil)
    }
    @IBAction func press_A3(_ sender: Any) {
        let noti_A3 = Notification.Name(rawValue: key_A3)
        NotificationCenter.default.post(name: noti_A3, object: nil)
    }
}
