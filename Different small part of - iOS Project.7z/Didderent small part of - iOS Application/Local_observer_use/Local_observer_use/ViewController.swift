//
//  ViewController.swift
//  Local_observer_use
//
//  Created by lab on 11/19/18.
//  Copyright © 2018 sa. All rights reserved.
//

import UIKit

let key_A1 = "key_A1"
let key_A2 = "key_A2"
let key_A3 = "key_A3"
let key_B1 = "key_B1"
let key_B2 = "key_B2"
let key_B3 = "key_B3"
let key_C1 = "key_C1"
let key_C2 = "key_C2"
let key_C3 = "key_C3"

var A1 = 0, A2 = 1, A3 = 3, B1 = 4, B2 = 5, B3 = 6, C1 = 7, C2 = 8, C3 = 9


class ViewController: UIViewController {

    @IBOutlet weak var homeLabel: UILabel!
    @IBOutlet weak var firstViewController: UIButton!
    @IBOutlet weak var secondViewController: UIButton!
    @IBOutlet weak var thirdViewController: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addObserver()
    }
    
    func addObserver(){
        let noti_A1 = Notification.Name(rawValue: key_A1)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.task_A1), name: noti_A1, object: nil)
        
        let noti_A2 = Notification.Name(rawValue: key_A2)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.task_A2), name: noti_A2, object: nil)
        
        let noti_A3 = Notification.Name(rawValue: key_A3)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.task_A3), name: noti_A3, object: nil)
        
        let noti_B1 = Notification.Name(rawValue: key_B1)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.task_B1), name: noti_B1, object: nil)
        
        let noti_B2 = Notification.Name(rawValue: key_B2)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.task_B2), name: noti_B2, object: nil)
        
        let noti_B3 = Notification.Name(rawValue: key_B3)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.task_B3), name: noti_B3, object: nil)
        
        let noti_C1 = Notification.Name(rawValue: key_C1)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.task_C1), name: noti_C1, object: nil)
        
        let noti_C2 = Notification.Name(rawValue: key_C2)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.task_C2), name: noti_C2, object: nil)
        
        let noti_C3 = Notification.Name(rawValue: key_C3)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.task_C3), name: noti_C3, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func task_A1(){
        A1 += 1
        homeLabel.text = " A1 = \(A1)"
    }


    @objc func task_A2(){
        A1 += 2
    }
    @objc func task_A3(){
        A1 += 3
    }
    @objc func task_B1(){
        A1 += 4
    }
    @objc func task_B2(){
        A1 += 5
    }
    @objc func task_B3(){
        A1 += 6
    }
    @objc func task_C1(){
        A1 += 7
    }
    @objc func task_C2(){
        A1 += 8
    }
    @objc func task_C3(){
        A1 += 9
    }
    
}

