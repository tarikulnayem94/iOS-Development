//
//  SecondViewController.swift
//  Local_observer_use
//
//  Created by lab on 11/19/18.
//  Copyright © 2018 sa. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var close: UIButton!
    @IBOutlet weak var b1: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var b3: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func secondViewClose(_ sender: Any) {
        let secondVC = storyboard?.instantiateViewController(withIdentifier: "homeStoryboard") as! ViewController
        present(secondVC, animated: true, completion: nil)
    }
    
    @IBAction func press_B1(_ sender: Any) {
        let noti_B1 = Notification.Name(rawValue: key_B1)
        NotificationCenter.default.post(name: noti_B1, object: nil)
    }
    @IBAction func press_B2(_ sender: Any) {
        let noti_B2 = Notification.Name(rawValue: key_B2)
        NotificationCenter.default.post(name: noti_B2, object: nil)
    }
    @IBAction func press_B3(_ sender: Any) {
        let noti_B3 = Notification.Name(rawValue: key_B3)
        NotificationCenter.default.post(name: noti_B3, object: nil)
    }
    
}
