//
//  ThirdViewController.swift
//  Local_observer_use
//
//  Created by lab on 11/19/18.
//  Copyright © 2018 sa. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet weak var close: UIButton!
    @IBOutlet weak var c1: UIButton!
    @IBOutlet weak var c2: UIButton!
    @IBOutlet weak var c3: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func thirdViewClose(_ sender: Any) {
        let thirdVC = storyboard?.instantiateViewController(withIdentifier: "homeStoryboard") as! ViewController
        present(thirdVC, animated: true, completion: nil)
    }
    
    @IBAction func press_C1(_ sender: Any) {
        let noti_C1 = Notification.Name(rawValue: key_C1)
        NotificationCenter.default.post(name: noti_C1, object: nil)
    }
    @IBAction func press_C2(_ sender: Any) {
        let noti_C2 = Notification.Name(rawValue: key_C2)
        NotificationCenter.default.post(name: noti_C2, object: nil)
    }
    @IBAction func press_C3(_ sender: Any) {
        let noti_C3 = Notification.Name(rawValue: key_C3)
        NotificationCenter.default.post(name: noti_C3, object: nil)
    }
}
