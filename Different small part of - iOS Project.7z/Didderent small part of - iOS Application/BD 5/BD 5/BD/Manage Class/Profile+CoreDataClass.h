//
//  Profile+CoreDataClass.h
//  BD
//
//  Created by digicon on 10/15/18.
//  Copyright © 2018 Digicon. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Book;

NS_ASSUME_NONNULL_BEGIN

@interface Profile : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Profile+CoreDataProperties.h"
