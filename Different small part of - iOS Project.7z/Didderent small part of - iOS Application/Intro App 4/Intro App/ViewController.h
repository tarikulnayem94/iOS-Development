//
//  ViewController.h
//  Intro App
//
//  Created by Admin on 8/13/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeViewController.h"

@interface ViewController : UIViewController<UITextFieldDelegate> {
    
    NSMutableDictionary *resultDic;
}
@property (weak, nonatomic) IBOutlet UILabel *tempLabel;

@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UITextField *fieldOne;
@property (weak, nonatomic) IBOutlet UITextField *fieldTwo;
@property (weak, nonatomic) IBOutlet UITextView *detailsTextView;

- (IBAction)buttonAction:(UIButton *)sender;
- (IBAction)substraction:(UIButton *)sender;
- (IBAction)multiplication:(UIButton *)sender;
- (IBAction)divition:(UIButton *)sender;


@end

