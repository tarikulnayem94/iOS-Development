
#import "ViewController.h"

@interface ViewController (){
 
}

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.fieldOne.delegate = self;
    self.fieldTwo.delegate = self;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touched)];
    [self.view addGestureRecognizer:tap];

    resultDic = [[NSMutableDictionary alloc] init];
    
  NSNotificationCenter *nc =  [NSNotificationCenter defaultCenter];
    
    [nc addObserver:self selector:@selector(keyboardWillHide) name:UIKeyboardWillHideNotification
             object:nil];
    
    [nc addObserver:self selector:@selector(keyboardWillShow) name:UIKeyboardWillShowNotification
             object:nil];

}

-(void)keyboardWillHide{
    CGRect rect = self.view.frame;
    rect.origin = CGPointMake(0, 64);
    
    self.view.frame = rect;
}

-(void)keyboardWillShow{
    
    CGRect rect = self.view.frame;
    rect.origin = CGPointMake(0, -170);
    
    self.view.frame = rect;
}


-(void)touched{
    [self.view endEditing:YES];
}



- (IBAction)buttonAction:(UIButton *)sender {
    
    int result = [_fieldOne.text intValue] +
                 [_fieldTwo.text intValue];
    
    _label.text = [NSString stringWithFormat:@"%@", @(result)];
    
    [resultDic setObject:@(result) forKey:sender.titleLabel.text];
    self.detailsTextView.text = resultDic.description;
}

- (IBAction)substraction:(UIButton *)sender {
    int result = [_fieldOne.text intValue] -
    [_fieldTwo.text intValue];
    
    _label.text = [NSString stringWithFormat:@"%@", @(result)];
    
    NSLog(@"%@", sender.titleLabel.text);
    
    [resultDic setObject:@(result) forKey:sender.titleLabel.text];
    self.detailsTextView.text = resultDic.description;

}

- (IBAction)multiplication:(UIButton *)sender {
    int result = [_fieldOne.text intValue] *
    [_fieldTwo.text intValue];
    
    _label.text = [NSString stringWithFormat:@"%@", @(result)];
    [resultDic setObject:@(result) forKey:sender.titleLabel.text];
    self.detailsTextView.text = resultDic.description;

}



- (IBAction)divition:(UIButton *)sender {
    int result = [_fieldOne.text intValue] /
    [_fieldTwo.text intValue];
    
    _label.text = [NSString stringWithFormat:@"%@", @(result)];
    [resultDic setObject:@(result) forKey:sender.titleLabel.text];
    self.detailsTextView.text = resultDic.description;

}

- (IBAction)buttonNextAction:(id)sender {
    
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    HomeViewController *vc = [board instantiateViewControllerWithIdentifier:@"HomeViewControllerID"];
    [self.navigationController pushViewController:vc animated:YES];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
    return YES;
}

@end
