//
//  main.m
//  Data Types
//
//  Created by Admin on 10/11/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
    
        NSMutableArray *ar = [[NSMutableArray alloc] init];
        
        [ar addObject:@"Ash"];
        [ar addObject:@"Mush"];
        [ar addObject:@"Fizz"];
        [ar addObject:@"SA"];
        
        NSInteger index  = [ar indexOfObject:@"Mush2"];
        
        if (index != LONG_MAX){
            NSLog(@"%ld", index);
        }
        
       
        NSString *s =  @"";
        
        for(int i=0; i<ar.count; i++){
//            s = [NSString stringWithFormat:@"%@, ()"]
//            s = [s stringByAppendingString:]
            NSString *t;
            
            if (i==ar.count-1){
                t  = [NSString stringWithFormat:@"(%d) %@", i+1, [ar objectAtIndex:i]];
            }
            else {
                t  = [NSString stringWithFormat:@"(%d) %@, ", i+1, [ar objectAtIndex:i]];
            }
            
            s = [NSString stringWithFormat:@"%@%@", s, t];
        }
        
        NSLog(@"%@", s);
        
//        s = [s substringToIndex:s.length-2];
//        NSLog(@"%@", s);
        
        for(NSString *u in ar){
            NSLog(@"%@ %ld", u, [ar indexOfObject:u]);
        }
        
        
        NSMutableDictionary *dic  = [[NSMutableDictionary alloc] init];
        [dic setObject:@"Akram" forKey:@(57)];
        [dic setObject:@"Bulbul" forKey:@(35)];
        [dic setObject:@"Pailot" forKey:@(40)];
        [dic setObject:@"Rafiq" forKey:@(71)];

        NSLog(@"Init dic : %@", dic);
        
        NSString *obj = [dic objectForKey:@(40)];
        NSLog(@"value : %@", obj);
        
        [dic setObject:@"Javed" forKey:@(35)];
        
        NSArray *keys = dic.allKeys;
        NSArray *values = dic.allValues;
        
        for(int i=0; i<keys.count; i++){
            NSLog(@"Key : %@, value : %@", [keys objectAtIndex:i], [dic objectForKey:[keys objectAtIndex:i]]);
        }
        
        
        for(NSString *key in keys){
            NSLog(@"Key : %@, value : %@", key, [dic objectForKey:key]);
        }



    }
    return 0;
}
