//
//  ViewController.swift
//  CurrencyBD
//
//  Created by lab on 11/10/18.
//  Copyright © 2018 jannat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var UIcurrency: UITextField!
    
    @IBOutlet weak var usd: UILabel!
    @IBOutlet weak var euro: UILabel!
    @IBOutlet weak var rupee: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func UIconverter(_ sender: Any) {
        
        var taka:Float = (UIcurrency.text == nil) ? 0.0 : (UIcurrency.text! as NSString).floatValue
        
        let USD = (taka*83.79)
        let EURO = (taka*95)
        let Rupee = (taka*1.16)
        
        usd.text = String(USD)
        euro.text = String(EURO)
        rupee.text = String(Rupee)
        
    }
    

}


