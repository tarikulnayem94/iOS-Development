//
//  main.m
//  Data Pass Segue
//
//  Created by lab on 9/22/18.
//  Copyright © 2018 skb. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
