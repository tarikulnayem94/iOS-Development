//
//  ViewController.m
//  Data Pass Segue
//
//  Created by lab on 9/22/18.
//  Copyright © 2018 skb. All rights reserved.
//

#import "ViewController.h"
#import "RedViewController.h"
#import "GreenViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([segue.identifier isEqualToString:@"RedSegue"]){
        RedViewController *redVU = segue.destinationViewController;
        redVU.infoString = self.showTEXT.text;
    }
    else{
        GreenViewController *greenVU = segue.destinationViewController;
        greenVU.stringGreen = self.ShowGreenText.text;
    }
}

@end
