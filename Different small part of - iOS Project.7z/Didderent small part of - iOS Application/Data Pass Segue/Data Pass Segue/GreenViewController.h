//
//  GreenViewController.h
//  Data Pass Segue
//
//  Created by lab on 9/22/18.
//  Copyright © 2018 skb. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GreenViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *greenLabelView;
@property (weak, nonatomic) NSString *stringGreen;


@end

NS_ASSUME_NONNULL_END
