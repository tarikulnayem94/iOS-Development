//
//  ViewController.h
//  Data Pass Segue
//
//  Created by lab on 9/22/18.
//  Copyright © 2018 skb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *showTEXT;

@property (weak, nonatomic) IBOutlet UITextField *ShowGreenText;


@end

