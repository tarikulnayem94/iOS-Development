//
//  LoginViewController.m
//  Data Pass
//
//  Created by Admin on 10/16/18.
//  Copyright © 2018 iZak. All rights reserved.
//

#import "LoginViewController.h"
#import "HomeViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)loginButtonAction:(id)sender {
    
    HomeViewController *homeVC = [self.storyboard instantiateViewControllerWithIdentifier:@"HomeViewControllerID"];
    homeVC.email = self.emailTextField.text;
    [self.navigationController pushViewController:homeVC animated:YES];

}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
   
    if([segue.identifier isEqualToString:@"SegueBlue"]){
        HomeViewController *homeVC = segue.destinationViewController;
        homeVC.email = self.emailTextField.text;
    }
    else {
        
    }
    
}


@end
