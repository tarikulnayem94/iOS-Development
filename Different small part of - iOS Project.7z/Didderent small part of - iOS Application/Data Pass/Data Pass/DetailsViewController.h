//
//  DetailsViewController.h
//  Data Pass
//
//  Created by Admin on 10/16/18.
//  Copyright © 2018 iZak. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailsViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
