//
//  FoodMenu.m
//  Restaurant Menu
//
//  Created by Admin on 9/15/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import "FoodMenu.h"

@implementation FoodMenu

@end
