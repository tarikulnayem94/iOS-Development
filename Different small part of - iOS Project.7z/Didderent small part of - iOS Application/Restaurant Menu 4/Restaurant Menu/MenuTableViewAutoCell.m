//
//  MenuTableViewAutoCell.m
//  Restaurant Menu
//
//  Created by lab on 9/29/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import "MenuTableViewAutoCell.h"

@implementation MenuTableViewAutoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
