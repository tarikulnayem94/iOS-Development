//
//  MenuListViewController.m
//  Restaurant Menu
//
//  Created by Admin on 9/12/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import "MenuListViewController.h"

@interface MenuListViewController ()

@end

@implementation MenuListViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.menuTableView.delegate = self;
    self.menuTableView.dataSource = self;
    
    self.title = @"Menu List";

}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.menuItems.count;
}

//-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    return 150;
//}

-(CGFloat) tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return UITableViewAutomaticDimension;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSLog(@"get the Cell at index %ld", indexPath.row);
    
    /*
    NSDictionary *dic = [self.menuItems objectAtIndex:indexPath.row];
    NSString *name = [dic objectForKey:@"NAME"];
    NSString *desc = [dic objectForKey:@"DESC"];
    NSString *imageName = [dic objectForKey:@"IMAGE"];
    */
    
    FoodMenu *food = [self.menuItems objectAtIndex:indexPath.row];
    
    MenuTableViewAutoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MenuTableViewAutoCellID"];
    cell.nameLabel.text = food.name;
    cell.descLabel.text = food.desc;
    cell.menuImageView.image = food.image;
    
    /*[UIImage imageNamed:food.imageName];*/
    
//    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"did select Cell at index %ld", indexPath.row);

    FoodMenu *food = [self.menuItems objectAtIndex:indexPath.row];

    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];

    MenuDetailsViewController *vc = [board instantiateViewControllerWithIdentifier:@"MenuDetailsViewControllerID"];
    vc.menu = food;
    [self.navigationController pushViewController:vc animated:YES];
}


@end
