//
//  MenuDetailsViewController.m
//  Restaurant Menu
//
//  Created by Admin on 9/17/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import "MenuDetailsViewController.h"

@interface MenuDetailsViewController ()

@end

@implementation MenuDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Details";


    self.nameLabel.text = self.menu.name;
    self.descLabel.text = self.menu.desc;
    self.menuImageView.image = [UIImage imageNamed:self.menu.imageName];
    self.menuImageView.image = self.menu.image;

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
