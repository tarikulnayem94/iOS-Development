//
//  FoodMenu.h
//  Restaurant Menu
//
//  Created by Admin on 9/15/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FoodMenu : NSObject

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *desc;
@property (strong, nonatomic) NSString *imageName;
@property (strong, nonatomic) UIImage *image;

@end

NS_ASSUME_NONNULL_END
