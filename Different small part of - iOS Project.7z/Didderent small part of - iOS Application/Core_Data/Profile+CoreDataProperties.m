//
//  Profile+CoreDataProperties.m
//  Core_Data
//
//  Created by lab on 10/10/18.
//  Copyright © 2018 Izak. All rights reserved.
//
//

#import "Profile+CoreDataProperties.h"

@implementation Profile (CoreDataProperties)

+ (NSFetchRequest<Profile *> *)fetchRequest {
	return [NSFetchRequest fetchRequestWithEntityName:@"Profile"];
}

@dynamic name;
@dynamic userID;
@dynamic email;

@end
