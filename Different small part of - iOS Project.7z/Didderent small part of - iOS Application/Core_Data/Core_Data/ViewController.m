//
//  ViewController.m
//  BD
//
//  Created by User on 10/10/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import "ViewController.h"
#import "EProfile.h"

@interface ViewController (){
    
    NSArray *dataArray;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.profileListTable.delegate  = self;
    self.profileListTable.dataSource  = self;

}
- (IBAction)saveAction:(id)sender {
    
    
}
- (IBAction)showAction:(id)sender {
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    EProfile *profile =  [dataArray objectAtIndex:indexPath.row];
    NSString *text = [NSString stringWithFormat:@"%@, %@",profile.name, profile.email];
    
    UITableViewCell *cell = [[UITableViewCell alloc] init];
    cell.textLabel.text = text;
    
    return cell;
    
}

@end
