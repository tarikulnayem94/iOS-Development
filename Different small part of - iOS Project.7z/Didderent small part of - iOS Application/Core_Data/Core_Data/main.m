//
//  main.m
//  Core_Data
//
//  Created by lab on 10/10/18.
//  Copyright © 2018 Izak. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
