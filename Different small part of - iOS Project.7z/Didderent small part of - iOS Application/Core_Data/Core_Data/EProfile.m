//
//  EProfile.m
//  Core_Data
//
//  Created by lab on 10/10/18.
//  Copyright © 2018 Izak. All rights reserved.
//

#import "EProfile.h"

@implementation EProfile

@end
