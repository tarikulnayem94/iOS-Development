//
//  ViewController.h
//  BD
//
//  Created by User on 10/10/18.
//  Copyright © 2018 Digicon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITextField *idTextField;
@property (weak, nonatomic) IBOutlet UITextField *nameTextfiled;
@property (weak, nonatomic) IBOutlet UITextField *emailTextFiled;

@property (weak, nonatomic) IBOutlet UITableView *profileListTable;

@end

