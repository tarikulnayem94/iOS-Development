//
//  ViewController.m
//  AutoLayout
//
//  Created by lab on 9/19/18.
//  Copyright © 2018 Digicon lab. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
