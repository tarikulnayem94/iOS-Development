//
//  SelectionViewController.swift
//  Delegate
//
//  Created by lab on 11/12/18.
//  Copyright © 2018 jannat. All rights reserved.
//

import UIKit


protocol SelectionDelegate {
    func Delegate (MSG:String, Type:String)
}

class SelectionViewController: UIViewController {

    
    
    var DelegateObject:SelectionDelegate!
    
    @IBOutlet weak var SelectionTextField: UITextField!
    @IBOutlet weak var TeacherITEMS: UIButton!
    @IBOutlet weak var StudentItems: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        StudentItems.layer.cornerRadius = StudentItems.frame.size.height/2
        TeacherITEMS.layer.cornerRadius = TeacherITEMS.frame.size.height/2
        
    }
    
    @IBAction func teacherAction(_ sender: Any) {
        
          msg = SelectionTextField.text!
        let teacherNotifi = Notification.Name(rawValue: TeacherKey)
        NotificationCenter.default.post(name: teacherNotifi, object: nil)
        
        dismiss(animated: true, completion: nil)
        
        
//        DelegateObject.Delegate(MSG: SelectionTextField.text!, Type: "Student")
//        dismiss(animated: true, completion: nil)
        
    
    
    
    
    
    }
    
    @IBAction func StudentAction(_ sender: Any) {
        
        
        msg = SelectionTextField.text!
        
        let stuNotifi = Notification.Name(rawValue: studentKey)
        NotificationCenter.default.post(name: stuNotifi, object: nil)
        
        dismiss(animated: true, completion: nil)
        
        
//        DelegateObject.Delegate(MSG: SelectionTextField.text!, Type: "Teacher")
//                dismiss(animated: true, completion: nil)
    
    
    
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
