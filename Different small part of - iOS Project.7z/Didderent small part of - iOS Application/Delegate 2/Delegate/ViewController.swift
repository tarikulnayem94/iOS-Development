//
//  ViewController.swift
//  Delegate
//
//  Created by lab on 11/12/18.
//  Copyright © 2018 jannat. All rights reserved.
//

import UIKit

let studentKey = "com.msiazn.student"
let TeacherKey = "com.msiazn.student"
var msg :String = ""

class ViewController: UIViewController{
    
    let teacherNotifi = Notification.Name(rawValue: TeacherKey)
    let stuNotifi = Notification.Name(rawValue: studentKey)
    
    @IBOutlet weak var HomeLabel: UILabel!
    @IBOutlet weak var HomeButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addObserver()
        
        HomeButton.layer.cornerRadius = HomeButton.frame.size.height/2
        
        
    }

@IBAction func ButtonPress(_ sender: Any) {
        
        let SelectionVC = storyboard?.instantiateViewController(withIdentifier: "X") as! LastViewController
        present(SelectionVC, animated: true, completion: nil)
    }
  
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func addObserver(){
        
        //Student
        
       NotificationCenter.default.addObserver(self,selector: #selector(ViewController.updateUIForTeacher(notification:)), name :stuNotifi,object: nil)
        
        //Teacher
        
        
        NotificationCenter.default.addObserver(self,selector: #selector(ViewController.updateUIForTeacher(notification:)), name :teacherNotifi,object: nil)
    }
    
    @objc func updateUIForTeacher(notification:Notification){
        
        HomeLabel.text = "Teacher Button was pressed with message :\(msg)"
        
        
        
    }
    
    @objc func updateUIForStudent(notification:Notification){
         HomeLabel.text = "Student Button was pressed with message :\(msg)"
        
    }
    
}

extension ViewController:SelectionDelegate{
    func Delegate(MSG: String, Type: String) {
        HomeLabel.text = Type + "and MSG is - " + MSG
    
    }
}

