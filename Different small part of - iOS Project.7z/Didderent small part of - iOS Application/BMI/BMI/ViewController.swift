                                                                                                                                                                                                                               //
//  ViewController.swift
//  BMI
//
//  Created by digicon on 11/10/18.
//  Copyright © 2018 digicon. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var UIweightinKG: UITextField!
    @IBOutlet weak var UIhightinCM: UITextField!
    
    @IBOutlet weak var UIresult: UILabel!
    @IBOutlet weak var UIcondition: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func BMIcalculate(_ sender: Any) {
        
        var hight:Float = (UIhightinCM.text == nil) ? 0.0 : (UIhightinCM.text! as NSString).floatValue
        hight = hight/100
        
        let weight:Float = (UIweightinKG.text == nil) ? 0.0 : (UIweightinKG.text! as NSString).floatValue
        
        let BMI = weight / (hight*hight)

        UIresult.text = String(BMI)
        
        if(BMI<=18)
        {
            UIcondition.text = String("you are under weight")
        }
        else if(BMI>=23)
        {
            UIcondition.text = String("you are over weight")
        }
        else
        {
            UIcondition.text = String("perfect")
        }
    }
    }
                                                                                                                                                                                                                

                                                                                                                                                                                                                               
                                                                                                                                                                                                                               
