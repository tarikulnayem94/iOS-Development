//
//  ViewController.swift
//  Calculator
//
//  Created by lab on 11/28/18.
//  Copyright © 2018 sa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var display: UITextView!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var percentButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var oneButton: UIButton!
    @IBOutlet weak var twoButton: UIButton!
    @IBOutlet weak var threeButton: UIButton!
    @IBOutlet weak var fourButton: UIButton!
    @IBOutlet weak var fiveButton: UIButton!
    @IBOutlet weak var sixButton: UIButton!
    @IBOutlet weak var sevenButton: UIButton!
    @IBOutlet weak var eightButton: UIButton!
    @IBOutlet weak var nineButton: UIButton!
    @IBOutlet weak var zeroButton: UIButton!
    @IBOutlet weak var pointButton: UIButton!
    @IBOutlet weak var multipleButton: UIButton!
    @IBOutlet weak var devideButton: UIButton!
    @IBOutlet weak var substructionButton: UIButton!
    @IBOutlet weak var additionButton: UIButton!
    @IBOutlet weak var equalButton: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func clearAction(_ sender: Any) {
    }
    
    @IBAction func percentageAction(_ sender: Any) {
    }
    
    @IBAction func deleteAction(_ sender: Any) {
    }
    
    @IBAction func oneAction(_ sender: Any) {
        Addnumberfunc(number: "7")

    }
    
    @IBAction func twoAction(_ sender: Any) {
        Addnumberfunc(number: "7")

    }
    
    @IBAction func threeAction(_ sender: Any) {
        Addnumberfunc(number: "7")

    }
    
    @IBAction func fourAction(_ sender: Any) {
        Addnumberfunc(number: "7")

    }
    
    @IBAction func fiveAction(_ sender: Any) {
        Addnumberfunc(number: "7")

    }
    
    @IBAction func sixAction(_ sender: Any) {
        Addnumberfunc(number: "7")

    }
    
    @IBAction func sevenAction(_ sender: Any) {
        Addnumberfunc(number: "7")

    }
    
    @IBAction func eightAction(_ sender: Any) {
        Addnumberfunc(number: "7")

    }
    
    @IBAction func nineAction(_ sender: Any) {
        Addnumberfunc(number: "7")

    }
    
    @IBAction func pointAction(_ sender: Any) {
    }
    
    @IBAction func multipleAction(_ sender: Any) {
    }
    
    @IBAction func devideAction(_ sender: Any) {
    }
    
    @IBAction func substructionAction(_ sender: Any) {
    }
    
    @IBAction func additionAction(_ sender: Any) {
    }
    
    @IBAction func equalAction(_ sender: Any) {
    }
}

