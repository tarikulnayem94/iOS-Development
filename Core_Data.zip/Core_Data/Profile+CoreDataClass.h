//
//  Profile+CoreDataClass.h
//  Core_Data
//
//  Created by lab on 10/10/18.
//  Copyright © 2018 Izak. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Profile : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Profile+CoreDataProperties.h"
