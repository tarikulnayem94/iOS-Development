//
//  Profile+CoreDataProperties.h
//  Core_Data
//
//  Created by lab on 10/10/18.
//  Copyright © 2018 Izak. All rights reserved.
//
//

#import "Profile+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Profile (CoreDataProperties)

+ (NSFetchRequest<Profile *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSNumber *userID;
@property (nullable, nonatomic, copy) NSString *email;

@end

NS_ASSUME_NONNULL_END
