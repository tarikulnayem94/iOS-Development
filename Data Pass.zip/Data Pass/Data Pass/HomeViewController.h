//
//  HomeViewController.h
//  Data Pass
//
//  Created by Admin on 10/16/18.
//  Copyright © 2018 iZak. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@property (strong, nonatomic)  NSString *email;

@end

NS_ASSUME_NONNULL_END
