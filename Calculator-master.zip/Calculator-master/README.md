## CALCULATOR

This is my first basic mac calculator app Using swift 4 with xcode 9 for iphone .
In this project we use
* switch cases
* if conditions 
* in button action calling function with arguments 
* bool conditions 
* basic arithmetic operations
* string concatenation 
* casting

HERE GO SCREENSHOT OF MY CALCULATOR

![screen shot 2017-11-16 at 11 43 30 am](https://user-images.githubusercontent.com/22389608/32877101-dc75d23e-cac5-11e7-9d28-1af3a663f82d.png)
