//
//  AppDelegate.h
//  movingDATAbetweenController
//
//  Created by lab on 8/9/18.
//  Copyright © 2018 Digimon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

