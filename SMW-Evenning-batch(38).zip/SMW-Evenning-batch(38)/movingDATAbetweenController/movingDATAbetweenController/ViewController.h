//
//  ViewController.h
//  movingDATAbetweenController
//
//  Created by lab on 8/9/18.
//  Copyright © 2018 Digimon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

