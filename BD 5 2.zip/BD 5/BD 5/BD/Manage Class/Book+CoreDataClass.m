//
//  Book+CoreDataClass.m
//  BD
//
//  Created by digicon on 10/15/18.
//  Copyright © 2018 Digicon. All rights reserved.
//
//

#import "Book+CoreDataClass.h"

@implementation Book

@end
