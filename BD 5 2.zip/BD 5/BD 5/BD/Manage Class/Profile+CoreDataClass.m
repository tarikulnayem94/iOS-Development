//
//  Profile+CoreDataClass.m
//  BD
//
//  Created by digicon on 10/15/18.
//  Copyright © 2018 Digicon. All rights reserved.
//
//

#import "Profile+CoreDataClass.h"

@implementation Profile

@end
