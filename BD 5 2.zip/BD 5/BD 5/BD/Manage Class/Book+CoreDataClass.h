//
//  Book+CoreDataClass.h
//  BD
//
//  Created by digicon on 10/15/18.
//  Copyright © 2018 Digicon. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Profile;

NS_ASSUME_NONNULL_BEGIN

@interface Book : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Book+CoreDataProperties.h"
